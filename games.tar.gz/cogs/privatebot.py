import discord
from discord.ext import commands

class PrivateBotsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - private_bots_info")

    @commands.command()
    async def privatebot(self, ctx):
        embed = discord.Embed(
            title="<a:bot2:1198804556017057963> Joinify Private Bots",
            description="Wish to own a bot just like ours?\nOpen a ticket to buy a private bot. We will host the bot for you so you do not need to worry, you can just sell roles and plans for money! You will earn the money back in no time. Just select one of our plans below and we will get you your private bot!",
            color=discord.Color.green()
        )

        embed.add_field(name="Prices:", value="<a:B_arrow2:1198810346207580221>•  Week plan: $15\n<a:B_arrow2:1198810346207580221>• Monthly plan: $25\n<a:B_arrow2:1198810346207580221>• Lifetime plan: $40\n<a:B_arrow2:1198810346207580221>• Source Code: $90", inline=False)
        embed.add_field(name="Payment Methods:", value="<a:Litecoin:1199503946318872677> <:bitcoin:1199503999364247563> :credit_card: <:Paypal:1199506009123725444>", inline=False)

        image_url = "https://media.discordapp.net/attachments/1201553882535440404/1202016777026928750/ezgif-3-1bcd569564.gif?ex=65cbec5c&is=65b9775c&hm=89382d5df66d65c769bd34c974db2999b3351efa5e4c675bb38ff1248e9c0ce3&="
        embed.set_image(url=image_url)

        button_url = "https://discord.com/channels/1198699628376363048/1198703869492986039"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="🛒 Purchase", url=button_url)
        view.add_item(item=item)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(PrivateBotsCog(bot))
