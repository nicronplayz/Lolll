import json
import discord
from discord.ext import commands

def normalize_role_name(role_name):
    # Helper function to normalize role names by converting to lowercase and removing spaces.
    return role_name.lower().replace(" ", "")

class RedeemCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # Load codes from a JSON file
        with open("codes.json", "r") as codes_file:
            self.codes_data = json.load(codes_file)

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - redeem")

    @commands.command()
    async def redeem(self, ctx, code):
        """Redeem a code for a specific role."""

        # Check if any role in the codes data has the provided code
        role_name = None
        for role, codes in self.codes_data.items():
            if code in codes:
                role_name = role
                break

        # Check if a role with the provided code was found
        if role_name is None:
            await ctx.reply(f"No role found for the provided code '{code}'.")
            return

        role_name_lower = normalize_role_name(role_name)

        # Check if the user already has the role
        if any(role.name.lower() == role_name_lower for role in ctx.author.roles):
            await ctx.reply(f"You already have the role '{role_name}'.")
            return

        # Add the role to the user
        role = discord.utils.get(ctx.guild.roles, name=normalize_role_name(role_name))
        if role:
            await ctx.author.add_roles(role)

            # Remove the redeemed code from the codes data
            self.codes_data[role_name].remove(code)

            await ctx.reply(f"Successfully redeemed code for role '{role_name}'.")
        else:
            await ctx.reply(f"Role '{role_name}' not found on the server.")

# ... (The rest of your code)

async def setup(bot):
    await bot.add_cog(RedeemCog(bot))
