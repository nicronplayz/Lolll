import discord
from discord.ext import commands

class EmojiCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - emoji")

    @commands.command()
    async def emoji(self, ctx, emoji: discord.PartialEmoji):
        """
        Add a custom emoji to the server.

        Usage:
            !emoji :emoji:
        """
        try:
            async with ctx.typing():
                if emoji.is_custom_emoji():
                    emoji_data = await emoji.read()
                else:
                    emoji_data = await emoji.guild.fetch_emoji(emoji.id).url.read()

                emoji_name = emoji.name if emoji.is_custom_emoji() else f"emoji_{emoji.id}"

                await ctx.guild.create_custom_emoji(name=emoji_name, image=emoji_data)
                await ctx.send(f"Emoji `{emoji_name}` added successfully!")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(EmojiCog(bot))
