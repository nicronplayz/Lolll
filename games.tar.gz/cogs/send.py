import discord
from discord.ext import commands

class SendCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - send")

    @commands.command()
    async def send(self, ctx):
        view = discord.ui.View() # Establish an instance of the discord.ui.View class
        style = discord.ButtonStyle.gray  # The button will be gray in color
        item = discord.ui.Button(style=style, label="Invite", url="https://discord.com/oauth2/authorize?client_id=1198755313411690536&scope=bot%20applications.commands&permissions=8")  # Create an item to pass into the view class.
        view.add_item(item=item)  # Add that item into the view class
        await ctx.send(view=view) 

async def setup(bot):
    await bot.add_cog(SendCog(bot))
