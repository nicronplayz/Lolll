import discord
from discord.ext import commands

class StockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - stock")

    @commands.command()
    async def stock(self, ctx):
        try:
            with open("tokens.txt", "r") as file:
                total_tokens = sum(1 for line in file)
            

            view = discord.ui.View()  # Establish an instance of the discord.ui.View class
            style = discord.ButtonStyle.gray  # The button will be gray in color
            item = discord.ui.Button(style=style, label="📚 Support", url="https://discord.com/channels/1198699628376363048/1198703869492986039")  # Create an item to pass into the view class.
            item3 = discord.ui.Button(style=style, label="🛒 Donate", url="https://joinify.mysellix.io")
            

            view.add_item(item=item)
            view.add_item(item=item3)

            embed = discord.Embed(
                title="<a:bot2:1198804556017057963> Members Count",
                description=f"<a:B_arrow2:1198810346207580221> The total number of members in the bot: {total_tokens}",
                color=discord.Color.green()
            )

            embed.set_footer(text=f"Requested by {ctx.author.display_name}")

            await ctx.send(view=view,embed=embed)

        except FileNotFoundError:
            await ctx.send("The 'tokens.txt' file was not found.")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(StockCog(bot))
