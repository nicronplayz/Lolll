import discord
from discord.ext import commands

class RewardsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - rewards")

    @commands.command()
    async def rewards(self, ctx):
        embed = discord.Embed(
            title="<a:bot2:1198804556017057963> Server Boost Rewards",
            description="Earn exclusive server boost rewards!",
            color=discord.Color.dark_theme()
        )
        embed.add_field(name="<a:nitro_boost:1199248721951608873> 1 Boost",
                        value="Unlock the Silver plan.",
                        inline=False)
        embed.add_field(name="<a:nitro_boost:1199248721951608873> 2 Boosts",
                        value="Upgrade to the Gold plan.",
                        inline=False)
        
        image_url = "https://media.discordapp.net/attachments/1203510895766937710/1203528883928965170/New_Project_3.png?ex=65d16c9e&is=65bef79e&hm=6d042ae95ac03de74dbbbe44070b6b413300d2a97bfad2158d3d129fc408ab51&=&format=webp&quality=lossless&width=1025&height=415"
        embed.set_image(url=image_url)

        button_url = "https://discord.com/channels/1198699628376363048/1203520854604906556"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="⭐ View Boosters", url=button_url)
        view.add_item(item=item)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(RewardsCog(bot))
