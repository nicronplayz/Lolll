import discord
from discord.ext import commands

class LeaveAllServersCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - leaveallservers") 

    @commands.command()
    async def leaveallservers(self, ctx):
        current_guild_id = ctx.guild.id

        for guild in self.bot.guilds:
            if guild.id != current_guild_id:
                try:
                    await guild.leave()
                    print(f"Left server: {guild.name} (ID: {guild.id})")
                except Exception as e:
                    print(f"Error leaving server {guild.name} (ID: {guild.id}): {e}")

        await ctx.send("Left all servers except the current one.")

async def setup(bot):
    await bot.add_cog(LeaveAllServersCog(bot))
