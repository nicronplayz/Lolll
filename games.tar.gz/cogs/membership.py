import discord
from discord.ext import commands

class MembershipCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - membership")

    @commands.command()
    async def membership(self, ctx):
        embed = discord.Embed(
            title="<a:bot2:1198804556017057963> Membership Plans",
            description="Note: Once you purchase, run the command `!redeem code` to claim your role.",
            color=discord.Color.dark_theme()
        )
        embed.add_field(name="<a:B_arrow2:1198810346207580221>• Bronze",
                        value="5 Members per command.\n$2",
                        inline=False)
        embed.add_field(name="<a:B_arrow2:1198810346207580221>• Silver",
                        value="10 Members per command.\n$3",
                        inline=False)
        embed.add_field(name="<a:B_arrow2:1198810346207580221>• Diamond",
                        value="20 Members per command.\n$4",
                        inline=False)
        embed.add_field(name="<a:B_arrow2:1198810346207580221>• Platinum",
                        value="35 Members per command.\n$5",
                        inline=False)
        embed.add_field(name="Payment Methods:", value="<a:Litecoin:1199503946318872677> <:bitcoin:1199503999364247563> :credit_card: <:Paypal:1199506009123725444>", inline=False)
        image_url = "https://media.discordapp.net/attachments/1203510895766937710/1203515801643126805/New_Project_3.png?ex=65d1606f&is=65beeb6f&hm=7952a46b49c354a05a28f893605a13b6251d2bd3102a2ab78a227a237bdffe3d&=&format=webp&quality=lossless&width=1025&height=415"
        embed.set_image(url=image_url)

        view = discord.ui.View()  # Establish an instance of the discord.ui.View class
        style = discord.ButtonStyle.gray  # The button will be gray in color
        item = discord.ui.Button(style=style, label="📚 Support", url="https://discord.com/channels/1198699628376363048/1203518788063203348")  # Create an item to pass into the view class.
        item3 = discord.ui.Button(style=style, label="🛒 Store", url="https://saoservices.sell.app")

        view.add_item(item=item3)
        view.add_item(item=item)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(MembershipCog(bot))
