import discord
from discord.ext import commands

class DeleteChannelsCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - delete_channels")

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def delete_all_channels(self, ctx):
        """
        Delete all channels in the server.

        Usage:
            !delete_all_channels
        """
        try:
            async with ctx.typing():
                for channel in ctx.guild.channels:
                    await channel.delete()

                await ctx.send("All channels have been deleted successfully!")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
   await bot.add_cog(DeleteChannelsCog(bot))
