import discord
from discord.ext import commands

class PaymentCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - payments")

    @commands.command()
    async def payments(self, ctx):
        embed = discord.Embed(
            title="<a:bot2:1198804556017057963> Our Payment Methods",
            description="Listed down below is our official payment methods",
            color=discord.Color.green()
        )
        embed.add_field(name="LTC:", value="<a:Litecoin:1199503946318872677> • `Lbh3QgYLfz9BuUz61JemU8NtKF3YW6tjZi`", inline=False)
        embed.add_field(name="BTC:", value="<:bitcoin:1199503999364247563> • `37JJWCmB9Fh5SG7oiNPqt765v8FXKL9D7f`", inline=False)
        embed.add_field(name="Stripe:", value=":credit_card: • `Order via our store or make a ticket`", inline=False)
        embed.add_field(name="PayPal:", value="<:Paypal:1199506009123725444> • `dekoshopdc@gmail.com`", inline=False)

        button_url = "https://joinify.mysellix.io"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="🛒 Store", url=button_url)
        view.add_item(item=item)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(PaymentCog(bot))
