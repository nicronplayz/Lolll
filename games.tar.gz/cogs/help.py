import discord
from discord.ext import commands

class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - help")

    @commands.command()
    async def help(self, ctx):
        try:
            view = discord.ui.View()  # Establish an instance of the discord.ui.View class
            style = discord.ButtonStyle.gray  # The button will be gray in color

            item = discord.ui.Button(style=style, label="📚 Support", url="https://discord.com/channels/1198699628376363048/1203518788063203348")  # Create an item to pass into the view class.
            item3 = discord.ui.Button(style=style, label="🛒 Store", url="https://saoservices.sell.app")
            

            view.add_item(item=item)
            view.add_item(item=item3)

            embed = discord.Embed(title='<a:bot2:1198804556017057963> SAO Commands', description='List of available commands:', color=discord.Color.green())
            commands_info = [
                {'name': '<a:B_arrow2:1198810346207580221> !djoin serverid', 'value': 'Joins a server using the provided server ID.', 'inline': False},
                {'name': '<a:B_arrow2:1198810346207580221> !addbot', 'value': 'Provides a link to add this bot to your server.', 'inline': False},
                {'name': '<a:B_arrow2:1198810346207580221> !stock', 'value': 'Amount of members in bot', 'inline': False},
                {'name': '<a:B_arrow2:1198810346207580221> !vouch stars message', 'value': 'Create a new vouch', 'inline': False},
                {'name': '<a:B_arrow2:1198810346207580221> !redeem code', 'value': 'Redeem a code for a plan', 'inline': False},
                {'name': '<a:B_arrow2:1198810346207580221> !payments', 'value': 'View our payments', 'inline': False},
            ]
            for command in commands_info:
                embed.add_field(name=command['name'], value=command['value'], inline=command['inline'])

            # Accessing the User object from the Member object to get avatar_url
            embed.set_footer(text=f"Requested by {ctx.author.display_name}")

            await ctx.send(view=view, embed=embed)
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(HelpCog(bot))
