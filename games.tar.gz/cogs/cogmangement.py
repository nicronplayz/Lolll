import discord
from discord.ext import commands

class CogManagement(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_check(self, ctx):
        # This check ensures that only the bot owner can use these commands
        return await self.bot.is_owner(ctx.author)

    @commands.command()
    async def enable_cog(self, ctx, cog_name: str):
        """Enable a cog."""
        try:
            await self.bot.load_extension(cog_name)
            await ctx.send(f"The cog `{cog_name}` has been enabled.")
        except commands.ExtensionNotFound:
            await ctx.send(f"No cog found with the name `{cog_name}`.")
        except commands.ExtensionAlreadyLoaded:
            await ctx.send(f"The cog `{cog_name}` is already enabled.")

    @commands.command()
    async def disable_cog(self, ctx, cog_name: str):
        """Disable a cog."""
        try:
            await self.bot.unload_extension(cog_name)
            await ctx.send(f"The cog `{cog_name}` has been disabled.")
        except commands.ExtensionNotLoaded:
            await ctx.send(f"The cog `{cog_name}` is not currently enabled.")

async def setup(bot):
    await bot.add_cog(CogManagement(bot))
