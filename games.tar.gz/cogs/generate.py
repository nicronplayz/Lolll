import json
import string
import random
import discord
from discord.ext import commands

def normalize_role_name(role_name):
    # Helper function to normalize role names by converting to lowercase and removing spaces.
    return role_name.lower().replace(" ", "")

class GenerateCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

        # Load codes from a JSON file
        with open("codes.json", "r") as codes_file:
            self.codes_data = json.load(codes_file)

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - redeem")
        
    @commands.command()
    async def gencode(self, ctx, role_name, amount: int = 1):
        """Generate codes for a specific role."""

        role_name_lower = normalize_role_name(role_name)

        # Check if the specified role exists in the codes data
        if role_name_lower not in self.codes_data:
            # If the role doesn't exist, create a new entry for it
            self.codes_data[role_name_lower] = []

        # Generate random codes
        new_codes = [''.join(random.choices(string.ascii_uppercase + string.digits, k=8)) for _ in range(amount)]

        # Append the new codes to the existing ones
        self.codes_data[role_name_lower].extend(new_codes)

        # Save the updated codes to the JSON file
        with open("codes.json", "w") as codes_file:
            json.dump(self.codes_data, codes_file, indent=2)

        await ctx.reply(f"Generated {amount} code(s) for role '{role_name}'. Codes: {', '.join(new_codes)}.")

# ... (The rest of your code)

async def setup(bot):
    await bot.add_cog(GenerateCog(bot))
