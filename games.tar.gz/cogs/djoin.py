import discord
from discord.ext import commands
import tls_client, os, requests
from base64 import b64encode
import json, time
import random
import asyncio
import aiohttp
from discord.ext.commands import cooldown, BucketType
from discord.ext.commands import CommandOnCooldown

GUILD_ID = 1198699628376363048 
allowed_channel_id = 1198705375118098572

def is_valid_channel(channel_id):
    async def predicate(ctx):
        return ctx.channel.id == channel_id
    return commands.check(predicate)

def is_valid_guild():
    def predicate(ctx):
        return ctx.guild.id == GUILD_ID
    return commands.check(predicate)

def is_allowed_channel():
    async def predicate(ctx):
        return ctx.channel.id == allowed_channel_id
    return commands.check(predicate)

with open('config.json') as config_file:
    config = json.load(config_file)

async def get_user(access: str):
    endp = "https://canary.discord.com/api/v9/users/@me"

    async with aiohttp.ClientSession() as session:
        async with session.get(endp, headers={"Authorization": f"Bearer {access}"}) as response:
            if response.status == 200:
                rjson = await response.json()
                return rjson['id']
            else:
                print(f"Failed to get user. Status code: {response.status}, Response: {await response.text()}")
                return None
            
__useragent__ = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36"  #requests.get('https://discord-user-api.cf/api/v1/properties/web').json()['chrome_user_agent']
build_number = 165486  #int(requests.get('https://discord-user-api.cf/api/v1/properties/web').json()['client_build_number'])
cv = "108.0.0.0"
__properties__ = b64encode(
  json.dumps(
    {
      "os": "Windows",
      "browser": "Chrome",
      "device": "PC",
      "system_locale": "en-GB",
      "browser_user_agent": __useragent__,
      "browser_version": cv,
      "os_version": "10",
      "referrer": "https://discord.com/channels/@me",
      "referring_domain": "discord.com",
      "referrer_current": "",
      "referring_domain_current": "",
      "release_channel": "stable",
      "client_build_number": build_number,
      "client_event_source": None
    },
    separators=(',', ':')).encode()).decode()


def get_headers(token):
  headers = {
    "Authorization": token,
    "Origin": "https://canary.discord.com",
    "Accept": "*/*",
    "X-Discord-Locale": "en-GB",
    "X-Super-Properties": __properties__,
    "User-Agent": __useragent__,
    "Referer": "https://canary.discord.com/channels/@me",
    "X-Debug-Options": "bugReporterEnabled",
    "Content-Type": "application/json"
  }
  return headers
os.system("cls" if os.name == "nt" else "clear")
tkn = config['bottoken']
secret = config['secret']
client_id = config['client_id']
redirect = "http://localhost:8080"
API_ENDPOINT = 'https://canary.discord.com/api/v9'
auth = f"https://canary.discord.com/api/oauth2/authorize?client_id={client_id}&redirect_uri={redirect}&response_type=code&scope=identify%20guilds.join"


async def exchange_code(code):
    data = {
        'client_id': client_id,
        'client_secret': secret,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect
    }
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    async with aiohttp.ClientSession() as session:
        async with session.post(str(API_ENDPOINT) + '/oauth2/token', data=data, headers=headers) as response:
            if response.status in (200, 201, 204):
                return await response.json()
            else:
                return False

async def add_to_guild(access_token, userID, guild):
    url = f"{API_ENDPOINT}/guilds/{guild}/members/{userID}"

    botToken = tkn
    data = {
        "access_token": access_token,
    }
    headers = {
        "Authorization": f"Bot {botToken}",
        'Content-Type': 'application/json'
    }

    async with aiohttp.ClientSession() as session:
        async with session.put(url=url, headers=headers, json=data) as response:
            return response.status

ROLE_ALLOWANCES = {
    'members': 3,
    'bronze': 5,
    'silver': 10,
    'diamond': 20,
    'platinum': 35
}




def get_tokens_for_role(role_name):
    with open("tokens.txt", "r") as file:
        role_tokens = [line.strip() for line in file]
    role_allowance = ROLE_ALLOWANCES.get(role_name.lower(), 0)
    return random.sample(role_tokens, role_allowance) if role_allowance > 0 else role_tokens




def normalize_role_name(role_name):
    # Helper function to normalize role names by converting to lowercase and removing spaces.
    return role_name.lower().replace(" ", "")

import traceback 

async def authorizer(token, guild):
    try:
        headers = get_headers(token)
        client = tls_client.Session(client_identifier="firefox_102")
        client.headers.update(headers)

        async with aiohttp.ClientSession() as session:
            async with session.post(auth, headers=headers, json={"authorize": "true"}) as response:
                if response.status in (200, 201, 204):
                    response_json = await response.json()
                    if isinstance(response_json, bool):
                        print("Failed to parse JSON response. Expected a dictionary, but received a boolean.")
                        return False

                    location = response_json.get('location')
                    if location is not None:
                        code = location.replace("http://localhost:8080?code=", "")
                        exchange_result = await exchange_code(code)
                        print("! Authorized Token")
                        access_token = exchange_result.get('access_token')  # Use get() here to safely access the key
                        if access_token:
                            userid = await get_user(access_token)
                            await add_to_guild(access_token, userid, guild)
                            print(f"! Added to Guild {guild}")
                            return True
                        else:
                            print("Failed to get 'access_token' from exchange response.")
                            return False
                    else:
                        print("Failed to get 'location' from response.")
                        return False
                elif response.status == 403:
                    # Handle 403 Forbidden (verification error)
                    print("Error termed token: Removing token from tokens.txt.")
                    
                    # Remove token from tokens.txt
                    remove_token_from_file(token)
                    
                    return False
                else:
                    # Log detailed error information
                    print(f"Failed to add to the guild. Status code: {response.status}, Response: {await response.text()}")
                    
                    # Log the traceback for better understanding of the error
                    traceback.print_exc()

                    return False
    except Exception as e:
        # Log any unexpected exceptions
        print(f"An unexpected error occurred: {str(e)}")
        traceback.print_exc()
        return False

def remove_token_from_file(token):
    # Remove token from tokens.txt
    try:
        with open("tokens.txt", "r") as file:
            lines = file.readlines()
        
        with open("tokens.txt", "w") as file:
            for line in lines:
                if line.strip() != token:
                    file.write(line)
    except Exception as e:
        # Log any exception during file operation
        print(f"An error occurred while removing token from tokens.txt: {str(e)}")
        traceback.print_exc()

    
class DjoinCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config_path = 'data/blacklisted.json'
        self.load_config()

    def load_config(self):
        try:
            with open(self.config_path, 'r') as file:
                self.config = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            # If file not found or empty, initialize with an empty dictionary
            self.config = {"blacklisted_servers": []}

    def save_config(self):
        with open(self.config_path, 'w') as file:
            json.dump(self.config, file, indent=4)
    
    def is_server_blacklisted(self, guild_id):
        return str(guild_id) in map(str, self.config["blacklisted_servers"])



    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - djoin")

    @commands.command()
    @is_valid_guild()
    @is_valid_channel(1203520307399229470)
    @cooldown(1, 30, BucketType.user)  # Allow 1 use every 30 seconds per user
    async def djoin(self, ctx, guild_id):
        print("Running djoin command")
        """Add the bot to the guild using the author's role allowance."""

        if self.is_server_blacklisted(ctx.guild.id):
            embed = discord.Embed(
                title="Server Blacklisted",
                description="This server is blacklisted and cannot use the command.",
                color=discord.Color.red()
            )
            view = discord.ui.View()
            style = discord.ButtonStyle.gray
            item = discord.ui.Button(style=style, label="🛒 Purchase Unblacklist", url="https://saoservices.sell.app")
            view.add_item(item=item)
            await ctx.send(view=view,embed=embed)
            return

        log_channel_id = 1199017641214480394

        async def add_bot_to_guild(guild, role_name, tokens):
            async def process_tokens():
                success_count = 0
                for token in tokens:
                    if await authorizer(token, guild.id):
                        success_count += 1
                return success_count

            # Call the asynchronous function properly by awaiting it
            success_count = await process_tokens()
            return success_count

        # Check if the bot is already a member of the specified guild.
        guild = self.bot.get_guild(int(guild_id))
        if guild is None:
            # The bot is not in the guild, generate an invite URL and send an error message.
            print("Bot is not in the guild.")

            view = discord.ui.View()
            style = discord.ButtonStyle.gray
            item = discord.ui.Button(style=style, label="🔗 Invite", url="https://discord.com/oauth2/authorize?client_id=1198755313411690536&scope=bot%20applications.commands&permissions=8")
            view.add_item(item=item)

            embed = discord.Embed(
                title="<a:no_:1198815807648567307> Oops!",
                description="It seems like I haven't been invited to the server yet!",
                color=discord.Color.red()
            )

            embed.set_footer(text=f"Requested by {ctx.author.display_name}")

            await ctx.send(view=view, embed=embed)
            return

        # Check the author's roles.
        user_roles = [normalize_role_name(role.name) for role in ctx.author.roles]
        allowed_roles = [role for role in ROLE_ALLOWANCES.keys() if role in user_roles]

        if not allowed_roles:
            await ctx.send("You don't have permission to add the bot to any guild.")
            return

        role_name = max(allowed_roles, key=lambda role: ROLE_ALLOWANCES[role])  # Pick the highest role from allowed roles

        tokens = get_tokens_for_role(role_name)
        if not tokens:
            embed = discord.Embed(
                title="Error",
                description=f"No more tokens left in stock, ping an Owner",
                color=discord.Color.red()
            )
            embed.set_image(url="https://media.discordapp.net/attachments/1198085238765666424/1198379520923795538/cat.jpg?ex=65beb0e6&is=65ac3be6&hm=41fecad1d8b")
            await ctx.send(embed=embed)
            return

        # Run the time-consuming part in the background
        task = asyncio.create_task(add_bot_to_guild(guild, role_name, tokens))

        try:
            # This part can run in the background while other commands are processed
            success_count = await task
        except Exception as e:
            # Handle exceptions if needed
            success_count = 0

        view = discord.ui.View()
        style = discord.ButtonStyle.gray
        item = discord.ui.Button(style=style, label="🔗 Upgrade", url="https://joinify.mysellix.io") 
        view.add_item(item=item)
        embed = discord.Embed(
            title="<a:verified:1198816322335821865> Success!",
            description=f"Added the members to the guild '{guild}' for the role '{role_name}' ({success_count}/{ROLE_ALLOWANCES.get(role_name, 0)} tokens used).",
            color=discord.Color.green()
        )
        embed.set_footer(text=f"Requested by {ctx.author.display_name}")
        await ctx.send(view=view, embed=embed)

        view2 = discord.ui.View()
        style_upgrade = discord.ButtonStyle.gray
        style_blacklist = discord.ButtonStyle.red
        style_ban = discord.ButtonStyle.danger

        item_upgrade = discord.ui.Button(style=style_upgrade, label="🔗 Upgrade", url="https://joinify.mysellix.io")
        item_blacklist = discord.ui.Button(style=style_blacklist, label="⚫ Blacklist", custom_id=f"blacklist_{guild_id}_{ctx.author.id}")
        item_ban = discord.ui.Button(style=style_ban, label="🔨 Ban", custom_id=f"ban_{guild_id}_{ctx.author.id}")

        view2.add_item(item=item_blacklist)
        view2.add_item(item=item_ban)

        log_embed = discord.Embed(
            title=f"New Log - {guild_id}",
            description=f"Guild '{guild}'\n Plan '{role_name}'\n ({success_count}/{ROLE_ALLOWANCES.get(role_name, 0)} tokens used).",
            color=discord.Color.green()
        )
        log_embed.set_footer(text=f"Requested by {ctx.author.display_name}")
        log_channel = ctx.guild.get_channel(log_channel_id)
        if log_channel:
            await log_channel.send(view=view2, embed=log_embed)

async def setup(bot):
    await bot.add_cog(DjoinCog(bot))
