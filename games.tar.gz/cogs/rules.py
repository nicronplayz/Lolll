import discord
from discord.ext import commands

class RulesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - rules")

    @commands.command()
    async def rules(self, ctx):
        embed = discord.Embed(
            title="Server Rules",
            description="Please read and follow these rules to ensure a positive experience for everyone.",
            color=discord.Color.green()
        )
        embed.add_field(name="1. Be respectful",
                        value="This means no mean, rude, or harassing comments. Treat others the way you want to be treated.",
                        inline=False)
        embed.add_field(name="2. No inappropriate language",
                        value="Keep use of profanity to a reasonable minimum. Any derogatory language towards any user is prohibited. You can swear in casual channels only, while the other channels should be kept free of any profane language.",
                        inline=False)
        embed.add_field(name="3. No spamming",
                        value="Do not send a lot of small messages right after each other. These disrupt the chat and make it hard to scroll through the server. Please keep your messages at least 5 words long while chatting.",
                        inline=False)
        embed.add_field(name="4. No NSFW material",
                        value="This server is meant to provide a safe place for us to share art, videos, advice, and other kinds of helpful material.",
                        inline=False)
        embed.add_field(name="5. No advertisements",
                        value="Don’t send invasive advertising, whether it be for other communities or streams. You can post your content in the media channel if it’s relevant and provides actual value for the community.",
                        inline=False)
        embed.add_field(name="6. No offensive names and profile pictures",
                        value="Keep your names and profile picture appropriate.",
                        inline=False)
        embed.add_field(name="7. Server raiding",
                        value="Server raiding is against Discord’s ToS. Any attempt to circumvent or bypass them can result in a permanent ban.",
                        inline=False)
        embed.add_field(name="8. Threats are forbidden",
                        value="Threats are prohibited and disallowed.",
                        inline=False)
        embed.add_field(name="9. Don’t share your personal information",
                        value="Do not share your personal information or the personal information of other users without their consent. This includes phone numbers, addresses, and any other sensitive information.",
                        inline=False)
        embed.add_field(name="10. Respect others’ privacy",
                        value="Do not invade the privacy of other users by asking for or sharing their personal information, or by sending unwanted DMs.",
                        inline=False)
        embed.add_field(name="11. Do not abuse server bots",
                        value="Only use server bots for their intended purposes and do not spam or misuse their commands.",
                        inline=False)
        embed.add_field(name="12. Do not excessively use caps or emojis in your messages",
                        value="This can be disruptive and make the chat difficult to follow.",
                        inline=False)
        embed.add_field(name="13. No blackmail, threats, or harassment",
                        value="Do not engage in blackmail, threats, or harassment of any kind, whether in public or private messages.",
                        inline=False)
        embed.add_field(name="14. Do not evade bans or mutes",
                        value="If you have been banned or muted, do not attempt to evade the punishment by creating alternate accounts or otherwise circumventing the restrictions.",
                        inline=False)
        embed.add_field(name="15. Keep content age-appropriate",
                        value="Ensure that all content you share in the server is age-appropriate.",
                        inline=False)
        embed.add_field(name="16. No recruiting for other servers or communities",
                        value="Do not recruit or promote other servers or communities in this server without prior approval from the server staff.",
                        inline=False)
        
        button_url = "https://discord.com/channels/1198699628376363048/1198703869492986039"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="🔗 Support", url=button_url)
        view.add_item(item=item)

        image_url = "https://media.discordapp.net/attachments/1201553882535440404/1202016777026928750/ezgif-3-1bcd569564.gif?ex=65cbec5c&is=65b9775c&hm=89382d5df66d65c769bd34c974db2999b3351efa5e4c675bb38ff1248e9c0ce3&="
        embed.set_image(url=image_url)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(RulesCog(bot))
