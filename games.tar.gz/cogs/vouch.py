import discord
from discord.ext import commands
import datetime
import sqlite3
from datetime import datetime

def add_vouch_to_database(stars, message, author, avatar_url):
    timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect('vouches.db')
    cursor = conn.cursor()

    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS vouches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                stars INTEGER,
                message TEXT,
                author TEXT,
                timestamp TEXT
            )
        ''')

        print("Table created or already exists")


        cursor.execute("INSERT INTO vouches (stars, message, author, avatar_url, timestamp) VALUES (?, ?, ?, ?, ?)",
                       (stars, message, author, avatar_url, timestamp))

        print("Vouch added to the database")

        conn.commit()

    except Exception as e:
        print(f"Error: {e}")

    finally:
        conn.close()

class VouchCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - vouch")

    @commands.command()
    async def vouch(self, ctx, stars: int, *, message):
        try:
            if stars < 0 or stars > 5:
                await ctx.send("Please provide a valid star rating between 0 and 5.")
                return

            user_avatar_url = str(ctx.author.avatar.url) if ctx.author.avatar else str(ctx.author.default_avatar.url) if isinstance(ctx.author, discord.Member) else str(ctx.author.avatar_url)

            add_vouch_to_database(stars, message, ctx.author.name, user_avatar_url)

            vouch_embed = discord.Embed(
                title="Vouch Submitted!",
                description=f"{'⭐' * stars}{'⭑' * (5 - stars)}\n\nVouch:\n{message}\n\nVouched by:\n{ctx.author.mention}\nVouched at:\n{datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}",
                color=discord.Color.gold()
            )
            vouch_embed.set_thumbnail(url=user_avatar_url)

            vouch_channel_id = 1198831846390255676  # Replace with your actual channel ID
            vouch_channel = ctx.guild.get_channel(vouch_channel_id)

            if vouch_channel:
                await vouch_channel.send(embed=vouch_embed)
                view = discord.ui.View()  # Establish an instance of the discord.ui.View class
                style = discord.ButtonStyle.gray  # The button will be gray in color
                item = discord.ui.Button(style=style, label="⭐ View", url="https://discord.com/channels/1198699628376363048/1198831846390255676")  # Create an item to pass into the view class.
                

                view.add_item(item=item)

                embed = discord.Embed(
                    title="<a:bot2:1198804556017057963> Vouch submitted successfully!",
                    description=f"<a:B_arrow2:1198810346207580221> {'⭐' * stars}{'⭑' * (5 - stars)}\n\nVouch:\n{message}",
                    color=discord.Color.green()
                )

                embed.set_footer(text=f"Requested by {ctx.author.display_name}")

                await ctx.reply(view=view,embed=embed)
            else:
                await ctx.send("Vouch channel not found. Please configure the vouch channel ID.")
        except Exception as e:
            print(f"Error in vouch command: {e}")

async def setup(bot):
    await bot.add_cog(VouchCog(bot))
