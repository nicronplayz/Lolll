import discord
from discord.ext import commands

class VerifyCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - verify")    

    @commands.command()
    async def verify(self, ctx):
        embed = discord.Embed(
            title="<a:bot2:1198804556017057963> Joinify",
            description="We specialize in discord member services",
            color=discord.Color.green()
        )
        embed.add_field(name="Server Verification",
                        value="To gain full access, click the button below.",
                        inline=False)
        embed.add_field(name="Guild Restore Verification",
                        value="We have added 100% trusted and safe Guild Restore Verification.",
                        inline=False)
        embed.add_field(name="Database Storage",
                        value="Verify to be stored in our database. Stay connected even if the server gets terminated.",
                        inline=False)
        embed.add_field(name="Contact Support",
                        value="For concerns or issues, reach out to our General Support team.",
                        inline=False)

        # You can customize the button URL as needed

        image_url = "https://media.discordapp.net/attachments/1198712684712042506/1199240745324924980/Thumbnail_Template.png?ex=65c1d2fa&is=65af5dfa&hm=6bbe160d483b48376e85c9d93e741058264bde6a42fcb113f4c2f1ecd87d0eab&=&format=webp&quality=lossless&width=840&height=473"
        embed.set_image(url=image_url)

        button_url = "https://restorecord.com/verify/JoinifyServices"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="✅ Verify", url=button_url)
        view.add_item(item=item)

        await ctx.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(VerifyCog(bot))
