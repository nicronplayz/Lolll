import discord
from discord.ext import commands

class UnbanAllCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - unban_all")

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban_all(self, ctx):
        """
        Unban all users from the server.

        Usage:
            !unban_all
        """
        try:
            async with ctx.typing():
                bans = await ctx.guild.bans()
                for ban_entry in bans:
                    await ctx.guild.unban(ban_entry.user)

                await ctx.send("All users have been unbanned successfully!")
        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(UnbanAllCog(bot))
