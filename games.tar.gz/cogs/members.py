import discord
from discord.ext import commands

class MembersCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - private_bots_info")

    @commands.command()
    async def members(self, ctx):
        embed = discord.Embed(
            title="🚀 Members",
            description="In need off online/offline members?\nWell we have you covered!",
            color=discord.Color.green()
        )
        embed.add_field(name="Offline Prices:", value="<a:nitro_boost:1199248721951608873>• 1000x = $13", inline=False)
        embed.add_field(name="Online Prices:", value="<a:nitro_boost:1199248721951608873>• 1000x = $26", inline=False)
        embed.add_field(name="Payment Methods:", value="<a:Litecoin:1199503946318872677> <:bitcoin:1199503999364247563> :credit_card: <:Paypal:1199506009123725444>", inline=False)

        image_url = "https://media.discordapp.net/attachments/1201553882535440404/1202016777026928750/ezgif-3-1bcd569564.gif?ex=65cbec5c&is=65b9775c&hm=89382d5df66d65c769bd34c974db2999b3351efa5e4c675bb38ff1248e9c0ce3&="
        embed.set_image(url=image_url)

        button_url = "https://discord.com/channels/1198699628376363048/1198703869492986039"  
        view = discord.ui.View()
        style = discord.ButtonStyle.link
        item = discord.ui.Button(style=style, label="🛒 Purchase", url=button_url)
        view.add_item(item=item)

        await ctx.send(view=view,embed=embed)

async def setup(bot):
    await bot.add_cog(MembersCog(bot))
