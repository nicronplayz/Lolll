import discord
from discord.ext import commands
import sqlite3
from datetime import datetime

class VouchCountCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - vouchcount")

    def get_total_vouch_count(self):
        conn = sqlite3.connect('vouches.db')
        cursor = conn.cursor()

        try:
            cursor.execute("SELECT COUNT(*) FROM vouches")
            total_vouch_count = cursor.fetchone()[0]
            return total_vouch_count

        except Exception as e:
            print(f"Error in get_total_vouch_count: {e}")
            return None

        finally:
            conn.close()

    @commands.command()
    async def vouchcount(self, ctx):
        """Get the total vouch count for all users."""

        total_vouch_count = self.get_total_vouch_count()

        if total_vouch_count is not None:
            embed = discord.Embed(
                title="<a:bot2:1198804556017057963> Total Vouch Count",
                description=f"Vouches - {total_vouch_count}",
                color=discord.Color.green()
            )
            embed.set_footer(text=f"Requested by {ctx.author.display_name}")

            await ctx.send(embed=embed)
        else:
            await ctx.send("Failed to retrieve total vouch count.")

# ... (The rest of your code)

async def setup(bot):
    await bot.add_cog(VouchCountCog(bot))
