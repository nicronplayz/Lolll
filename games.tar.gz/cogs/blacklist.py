import discord
from discord.ext import commands
import json

class BlacklistCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config_path = 'data/blacklisted.json'
        self.load_config()

    def load_config(self):
        try:
            with open(self.config_path, 'r') as file:
                self.config = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            # If file not found or empty, initialize with an empty dictionary
            self.config = {}

        # Ensure the key "blacklisted_servers" is present
        self.config.setdefault("blacklisted_servers", [])

    def save_config(self):
        with open(self.config_path, 'w') as file:
            json.dump(self.config, file, indent=4)

    @commands.Cog.listener()
    async def on_ready(self):
        print("Command loaded - blacklist")
        self.load_config()

    @commands.command()
    @commands.has_permissions(administrator=True)
    async def blacklist(self, ctx, server_id: int):
        """
        Blacklist a server by ID.

        Usage:
            !blacklist <server_id>
        """
        try:
            if server_id not in self.config["blacklisted_servers"]:
                self.config["blacklisted_servers"].append(server_id)
                self.save_config()
                await ctx.send(f"Server with ID {server_id} has been blacklisted.")
            else:
                await ctx.send(f"Server with ID {server_id} is already blacklisted.")

        except Exception as e:
            await ctx.send(f"An error occurred: {e}")

async def setup(bot):
    await bot.add_cog(BlacklistCog(bot))
