from flask import Flask, render_template
import sqlite3

app = Flask(__name__)

def get_all_vouches_from_database():
    conn = sqlite3.connect('../vouches.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM vouches")
    vouches = cursor.fetchall()

    conn.close()

    return vouches

@app.route('/')
def index():
    vouches = get_all_vouches_from_database()
    return render_template('index.html', vouches=vouches)

if __name__ == '__main__':
    app.run(debug=True)
